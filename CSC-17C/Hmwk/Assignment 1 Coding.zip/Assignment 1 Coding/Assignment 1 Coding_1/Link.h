/*
 * Author: Dr. Mark E. Lehr
 * Created on March 8th, 2017, 8:01 PM
 * Purpose: Singularly Linked List
 */

#ifndef LINK_H
#define	LINK_H

struct Link{
    int data;
    Link *linkPtr;
};

#endif	/* LINK_H */
