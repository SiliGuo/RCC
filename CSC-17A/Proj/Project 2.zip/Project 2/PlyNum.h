/* 
 * File:   PlyNum.h
 * Author: siliguo
 *
 * Created on December 8, 2016, 1:26 AM
 */

#ifndef PLYNUM_H
#define PLYNUM_H

struct PlyNum {
    int num[3];
};


#endif /* PLYNUM_H */

