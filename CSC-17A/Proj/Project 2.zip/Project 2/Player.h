/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Player.h
 * Author: siliguo
 *
 * Created on December 8, 2016, 11:08 AM
 */

#ifndef PLAYER_H
#define PLAYER_H

#include "Card.h"
#include "PlyNum.h"

class Player : public Card {
private:
    Card *card;
    int rank;
    int money;
    int bet;

public:
    Player();
    ~Player(){
        delete [] card;
    }
    void setCard(PlyNum);
    void setRank();
    void setMoney(int);
    void setBet(int);

    Card *getCard() const {
        return card;
    }

    int getRank() const {
        return rank;
    }
    int getMoney() const {
        return money;
    }
    int getBet() const {
        return bet;
    }

};

#endif /* PLAYER_H */

