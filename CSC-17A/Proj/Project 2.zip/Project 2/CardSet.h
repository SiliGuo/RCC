/* 
 * File:   CardSet.h
 * Author: siliguo
 *
 * Created on December 9, 2016, 1:19 AM
 */

#ifndef CARDSET_H
#define CARDSET_H

#include "Card.h"

struct CardSet{
    Card *card1;
    Card *card2;
    Card *card3;
};


#endif /* CARDSET_H */

