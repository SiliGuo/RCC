var searchData=
[
  ['player',['Player',['../class_player.html',1,'']]],
  ['plynum',['PlyNum',['../struct_ply_num.html',1,'']]]
];
