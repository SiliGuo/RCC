var searchData=
[
  ['getbet',['getBet',['../class_player.html#af72bd8540101dd0f76c4a00c6b3a7982',1,'Player']]],
  ['getcard',['getCard',['../class_player.html#a6944db2ca2b4fd6736ef57be8b4abc05',1,'Player']]],
  ['getmoney',['getMoney',['../class_player.html#aed6ceb1d2d434747fbea5a7fc9f829e4',1,'Player']]],
  ['getname',['getName',['../class_card.html#a7b4e9a445eebedb4aa38cb9320a48207',1,'Card']]],
  ['getnum',['getNum',['../class_card.html#afdd26a7d861f1dae28dd967b3491fdd3',1,'Card']]],
  ['getrank',['getRank',['../class_player.html#a903c68ffc821cba6e813a4d3b0b4c770',1,'Player']]],
  ['getsuit',['getSuit',['../class_card.html#abfb09282f9920c235b464fb7f714b56c',1,'Card']]],
  ['getvalue',['getValue',['../class_card.html#a3df85ce283a6e38b719ffe25f3d4610a',1,'Card']]]
];
