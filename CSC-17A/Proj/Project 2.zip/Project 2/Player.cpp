/* 
 * File:   Player.cpp
 * Author: siliguo
 * 
 * Created on December 8, 2016, 11:08 AM
 */
#include <cstring>

#include "Player.h"

Player::Player() {
    rank = 0;
    money = 1000;
    bet = 0;
}

void Player::setCard(PlyNum p) {
    card = new Card[3];

    for (int i = 0; i < 3; i++) {
        this->card[i].setNum(p.num[i]);
        card[i].setNum(p.num[i]);
    }
}

void Player::setRank() {
    char *suit = new char[3];
    int *val = new int[3];
    for (int i = 0; i < 3; i++) {
        suit[i] = card[i].getSuit();
        val[i] = card[i].getValue();
    }

    //Check for rank 0
    if (val[0] == 1 && val[1] == 2 && val[2] == 4) {
        rank = 0;
    }
    //Check for rank 1
    if (val[0] != val[1] && val[1] != val[2]) {
        rank = 1;
    }
    //Check for rank 2
    if ((val[0] == val[1] && val[1] != val[2]) ||
            (val[1] == val[2] && val[0] != val[1])) {
        rank = 2;
    }
    //Check for rank 3, 4, 5
    if (suit[0] == suit[1] && suit[1] == suit[2]) {
        if (val[0] + 1 == val[1] && val[1] + 1 == val[2]) {
            rank = 5;
        } else {
            rank = 4;
        }
    } else {
        if (val[0] + 1 == val[1] && val[1] + 1 == val[2]) {
            rank = 3;
        }
    }
    //Check for rank 6
    if (val[0] == val[1] && val[1] == val[2]) {
        rank = 6;
    }

}

void Player::setMoney(int m){
    money = m;
}

void Player::setBet( int b){
    bet = b;
}