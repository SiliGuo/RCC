/* 
 * File:   Card.h
 * Author: gsl
 *
 * Created on October 28, 2016, 3:19 PM
 */

#ifndef CARD_H
#define CARD_H

struct Card {
    char suit;
    char number;
};

#endif /* CARD_H */

