/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   company.h
 * Author: gsl
 *
 * Created on October 19, 2016, 7:47 PM
 */

#ifndef COMPANY_H
#define COMPANY_H

struct Company {
    string name;
    int quarter;
    int sale;
};

#endif /* COMPANY_H */

